import pulumi
# from pulumi import Output
# from pulumi_random.random_password import RandomPassword
from pulumi_kubernetes.core.v1 import Namespace, Service
from pulumi_kubernetes.helm.v3 import Release, ReleaseArgs, RepositoryOptsArgs

namespace = Namespace("argocd")

# redis_password = RandomPassword("pass", length=10)

release_args = ReleaseArgs(
    chart="argo-cd",
    repository_opts=RepositoryOptsArgs(
        repo="https://charts.bitnami.com/bitnami"
    ),
    version="4.2.5",
    namespace=namespace.metadata["name"],

    # Values from Chart's parameters specified hierarchically,
    # see https://artifacthub.io/packages/helm/bitnami/redis/13.0.0#parameters
    # for reference.
    values={
        "server": {
            "service": {
                "type": "LoadBalancer",
            }
        },
        "secret": {
            "argocdServerAdminPassword": "null",
        }
    },


    # By default Release resource will wait until all created resources
    # are available. Set this to true to skip waiting on resources being
    # available.
    skip_await=False)

release = Release("argocd-helm", args=release_args)

# We can look up resources once the release is installed. The release's
# status field is set once the installation completes, so this, combined
# with `skip_await=False` above, will wait to retrieve the Redis master
# ClusterIP until all resources in the Chart are available.
#status = release.status
#srv = Service.get("redis-master-svc",
#                  Output.concat(status.namespace, "/", status.name, "-master"))
#pulumi.export("redisMasterClusterIP", srv.spec.cluster_ip)
